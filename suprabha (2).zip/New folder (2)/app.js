function showMessage(action) {
    alert(action + " selected!");
}