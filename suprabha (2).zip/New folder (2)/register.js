
const images = ["Untitled.jpg", "d.jpg", "Kd.jpg"];
let currentImageIndex = 0;


function changeImage() {
  currentImageIndex = (currentImageIndex + 1) % images.length;
  document.getElementById('schoolImage').src = images[currentImageIndex];
}

setInterval(changeImage, 5000);

const correctPassword = '20670708';
const passwordField = 
document.getElementById('password');
const errorMessage =
 document.getElementById('errorMessage');
const form=
document.getElementById('registerForm');


passwordField.addEventListener('input', function() {
  if (passwordField.value !== correctPassword) {
    errorMessage.textContent = 'Password is incorrect. Please enter the correct password.';
    errorMessage.style.display = 'block';
  } else {
    errorMessage.style.display = 'none';
  }
});


form.addEventListener('submit', function(event) {
  if (passwordField.value !== correctPassword) {
    event.preventDefault();
    errorMessage.textContent = 'Please enter the correct password.';
    errorMessage.style.display = 'block';
  }
});