function showDetails(type) {
    const details = document.getElementById('details');
    const detailsText = document.getElementById('details-text');
  
    if (type === 'vision') {
      detailsText.textContent =
        'Our vision is to nurture the intellectual, emotional, and social growth of students, helping them achieve their dreams and become responsible global citizens.We help them to identify their true goals and help thrive on that path.We always ensure they walk on a right path to achieve success';
    } else if (type === 'lab') {
      detailsText.textContent =
        'Our laboratories are equipped with modern tools and resources, enabling hands-on experiments in science,technology, and innovation. We ensure they learn not only theoritihelps them to visualize the contents in books in real world';
    } else if (type === 'services') {
      detailsText.textContent =
        'We offer various services such as career counseling, extrcal but practical learning too which acurricular activities, health support, and a focus on overall student well-being. We accept students as our children and help on walk on a right walk being true guardians. We ensure that they learn in a peaceful,effective environment with full confidence and comfort.';
} else if (type === 'transportation') {
    detailsText.textContent =
      'We offer various services such as transporation too. We ensure that parents do not take so much time to drop and pick up their children,disturbing their normal schedule. Thats why we provide full time reliable transportation service';
  }
 else if (type === 'technology') {
    detailsText.textContent =
      'We offer children with up to date and high cutting edge technological tools that ensures that students learn in an effective and technological environment which priortizes their practical and hand-on learning that helps them to achieve their aim in life. ';
  }
    detailsText.style.fontSize="30px";
    detailsText.style.fontWeight="bolder";
    detailsText.style.fontStyle="Georgia"


  
    details.classList.remove('hidden');
  }
  
  function hideDetails() {
    const details = document.getElementById('details');
    details.classList.add('hidden');
  }