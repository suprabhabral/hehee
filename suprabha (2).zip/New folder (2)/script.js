
const images = ["14.jpg","what.jpg","sports.jpg"]; 

const imagecontainer = document.getElementById("image-container");

let currentIndex = 0;


function updateImage(index) {
  imageContainer.style.backgroundImage = `url(${images[index]})`;
}


imageContainer.addEventListener("mousemove", (event) => {

  const xPosition = event.clientX / window.innerWidth;
  
 
  currentIndex = Math.floor(xPosition * images.length);

  updateImage(currentIndex);
});

updateImage(0);